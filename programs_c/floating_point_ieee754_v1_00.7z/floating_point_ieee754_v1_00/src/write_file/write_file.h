#ifndef _WRITE_FILE_H
#define _WRITE_FILE_H
	
void write_data_file(int data, int end);
	
#endif
