#ifndef _IEEE754X32_H
#define _IEEE754X32_H
	
int convert_ieee754(float data, int n);
	
#endif
