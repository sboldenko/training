#ifndef _READ_FILE_H
#define _READ_FILE_H
		
float read_data_file(int count);
	
#endif
